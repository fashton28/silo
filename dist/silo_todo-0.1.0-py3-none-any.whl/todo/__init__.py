"""Todo CLI - A terminal-based todo list with vim-style navigation."""

__version__ = "0.1.0"

